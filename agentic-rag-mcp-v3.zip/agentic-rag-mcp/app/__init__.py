"""Company knowledge MCP server: search, database, calculator and time tools for an MCP client."""
