# IT Security Guidelines - Muster GmbH

## Passwords and login
Passwords must have at least 14 characters. Multi-factor authentication (MFA) is mandatory for
email, the VPN and the HR portal. Passwords are never shared, not even with the IT team.

## Devices
All company laptops use full-disk encryption and lock automatically after 5 minutes of inactivity.
Lost or stolen devices must be reported to the IT helpdesk immediately.

## Phishing
Suspicious emails are forwarded to security@muster.example within 1 hour of receipt. Do not click
links or open attachments in such emails. If you already did, disconnect from the network and call
the IT helpdesk on extension 4711.

## Software
Only software from the company catalog may be installed. Requests for new software go through the
IT helpdesk and are answered within 5 working days.
