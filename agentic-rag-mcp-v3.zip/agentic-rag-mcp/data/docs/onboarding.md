# Onboarding Guide - Muster GmbH

## First day
New employees start at 9:00 at the reception desk in Rosenheim. IT hands out the laptop and the
MFA token at 9:30. The team lunch with the new colleague is on the first day at 12:30.

## Buddy system
Every new employee gets a buddy from their own team for the first 3 months. The buddy answers
everyday questions and introduces the new colleague to the other departments.

## Probation
The probation period is 6 months. A feedback conversation with the team lead takes place after
3 months and again before the end of the probation period.

## Working hours
Core working hours are 10:00 to 15:00. The regular working week has 40 hours; working from home
is possible on up to 3 days per week after the first month.
