# Vacation Policy - Muster GmbH

## Annual leave
Full-time employees receive 30 days of paid annual leave per calendar year.
Employees who join during the year earn 2.5 days per full month of employment in their first year.

## Requesting leave
Leave is requested in the HR portal. Absences longer than 5 consecutive working days must be
requested at least 2 weeks in advance. The team lead approves or declines within 3 working days.

## Carry-over
Unused leave can be carried over to the next year and must be taken by March 31. After that date
carried-over days expire, unless illness or parental leave prevented the employee from taking them.

## Public holidays
Public holidays in Bavaria are not counted as leave days. Christmas Eve and New Year's Eve are
half days for everyone.
